
-- Profiles
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  nome text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
create policy "own profile select" on public.profiles for select using (auth.uid() = id);
create policy "own profile insert" on public.profiles for insert with check (auth.uid() = id);
create policy "own profile update" on public.profiles for update using (auth.uid() = id);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, nome)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'nome', split_part(new.email,'@',1)));
  return new;
end; $$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

-- Objetivos do imóvel
create table public.objetivos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  nome text not null default 'Meu imóvel',
  valor_imovel numeric(14,2) not null,
  percentual_entrada numeric(5,2) not null default 20,
  prazo_meses int not null default 36,
  valor_ja_guardado numeric(14,2) not null default 0,
  taxa_cdi_anual numeric(6,3) not null default 13.65,
  percentual_cdi numeric(6,2) not null default 100,
  percentual_custos_extras numeric(5,2) not null default 5,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.objetivos enable row level security;
create policy "own objetivo all" on public.objetivos for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Pessoas (casal)
create table public.pessoas (
  id uuid primary key default gen_random_uuid(),
  objetivo_id uuid not null references public.objetivos(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  nome text not null,
  renda_mensal numeric(14,2) not null default 0,
  gastos_mensais numeric(14,2) not null default 0,
  aporte_mensal numeric(14,2) not null default 0,
  created_at timestamptz not null default now()
);
alter table public.pessoas enable row level security;
create policy "own pessoas all" on public.pessoas for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Aportes extras
create table public.aportes_extras (
  id uuid primary key default gen_random_uuid(),
  objetivo_id uuid not null references public.objetivos(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  pessoa_id uuid references public.pessoas(id) on delete set null,
  data date not null,
  valor numeric(14,2) not null,
  origem text not null default 'Outro',
  created_at timestamptz not null default now()
);
alter table public.aportes_extras enable row level security;
create policy "own aportes all" on public.aportes_extras for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index on public.pessoas(objetivo_id);
create index on public.aportes_extras(objetivo_id);
create index on public.objetivos(user_id);
