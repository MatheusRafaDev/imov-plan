ALTER TABLE public.objetivos
  ADD COLUMN IF NOT EXISTS data_inicio date NOT NULL DEFAULT CURRENT_DATE,
  ADD COLUMN IF NOT EXISTS data_fim date;

UPDATE public.objetivos
  SET data_fim = (data_inicio + (prazo_meses || ' months')::interval)::date
  WHERE data_fim IS NULL;