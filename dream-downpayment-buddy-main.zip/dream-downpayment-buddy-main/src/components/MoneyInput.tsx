import * as React from "react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

type Props = Omit<React.ComponentProps<"input">, "value" | "onChange" | "type"> & {
  value: number;
  onChange: (value: number) => void;
  /** "money" -> R$ 1.234,56 | "decimal" -> 1.234,56 | "percent" -> 13,65 % */
  variant?: "money" | "decimal" | "percent";
  decimals?: number;
};

const fmt = (n: number, decimals: number) =>
  (isFinite(n) ? n : 0).toLocaleString("pt-BR", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });

// Aceita "1.234,56", "1234,56", "1234.56", "1,5", ".5" etc.
function parseBR(raw: string): number {
  if (!raw) return 0;
  let s = raw.replace(/[^\d,.\-]/g, "").trim();
  if (!s) return 0;
  const hasComma = s.includes(",");
  const hasDot = s.includes(".");
  if (hasComma && hasDot) {
    // assume ponto = milhar, vírgula = decimal
    s = s.replace(/\./g, "").replace(",", ".");
  } else if (hasComma) {
    s = s.replace(",", ".");
  } else if (hasDot) {
    // só ponto: se houver mais de um, é separador de milhar
    const parts = s.split(".");
    if (parts.length > 2) s = parts.join("");
    // senão mantém como decimal (ex.: "1234.56")
  }
  const n = parseFloat(s);
  return isNaN(n) ? 0 : n;
}

export const MoneyInput = React.forwardRef<HTMLInputElement, Props>(
  ({ value, onChange, variant = "money", decimals, className, onFocus, onBlur, placeholder, ...rest }, ref) => {
    const dec = decimals ?? 2;
    const [text, setText] = React.useState<string>("");
    const [focused, setFocused] = React.useState(false);

    const display = focused ? text : fmt(Number(value) || 0, dec);

    return (
      <div className="relative">
        {variant === "money" && (
          <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">
            R$
          </span>
        )}
        {variant === "percent" && (
          <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">
            %
          </span>
        )}
        <Input
          ref={ref}
          type="text"
          inputMode="decimal"
          placeholder={placeholder}
          className={cn(
            "num text-right",
            variant === "money" && "pl-9",
            variant === "percent" && "pr-8",
            className,
          )}
          value={display}
          onFocus={(e) => {
            setFocused(true);
            // entra no modo edição com a representação simples
            const v = Number(value) || 0;
            setText(v ? String(v).replace(".", ",") : "");
            requestAnimationFrame(() => e.target.select());
            onFocus?.(e);
          }}
          onChange={(e) => {
            // permite apenas dígitos, vírgula, ponto e sinal
            const filtered = e.target.value.replace(/[^\d,.\-]/g, "");
            setText(filtered);
            onChange(parseBR(filtered));
          }}
          onBlur={(e) => {
            setFocused(false);
            const n = parseBR(text);
            onChange(n);
            onBlur?.(e);
          }}
          {...rest}
        />
      </div>
    );
  },
);
MoneyInput.displayName = "MoneyInput";
