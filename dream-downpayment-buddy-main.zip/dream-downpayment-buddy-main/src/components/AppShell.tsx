import { ReactNode } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { Home, Users, Calculator, LineChart, LogOut, Building2 } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";

const nav = [
  { to: "/app/objetivo", icon: Building2, label: "Imóvel" },
  { to: "/app/pessoas", icon: Users, label: "Casal" },
  { to: "/app/planejamento", icon: Calculator, label: "Plano" },
  { to: "/app/resultado", icon: LineChart, label: "Resultado" },
];

export const AppShell = ({ children }: { children: ReactNode }) => {
  const { signOut, user } = useAuth();
  const loc = useLocation();
  return (
    <div className="min-h-screen bg-gradient-cream">
      <header className="border-b border-border/60 bg-background/70 backdrop-blur sticky top-0 z-30">
        <div className="container flex h-16 items-center justify-between gap-4">
          <NavLink to="/app/objetivo" className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-gradient-warm grid place-items-center shadow-glow">
              <Home className="h-4 w-4 text-accent-foreground" />
            </div>
            <span className="font-display text-xl font-semibold">Casa<span className="text-accent">.</span>plan</span>
          </NavLink>
          <nav className="hidden md:flex items-center gap-1">
            {nav.map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                className={({ isActive }) =>
                  `px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    isActive ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground hover:bg-secondary/60"
                  }`
                }
              >
                {n.label}
              </NavLink>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <span className="hidden sm:inline text-xs text-muted-foreground">{user?.email}</span>
            <Button variant="ghost" size="sm" onClick={signOut}>
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <nav className="md:hidden border-t border-border/60 bg-background/70">
          <div className="container flex">
            {nav.map((n) => {
              const active = loc.pathname.startsWith(n.to);
              return (
                <NavLink key={n.to} to={n.to} className={`flex-1 py-2 grid place-items-center text-xs gap-0.5 ${active ? "text-accent" : "text-muted-foreground"}`}>
                  <n.icon className="h-4 w-4" />
                  {n.label}
                </NavLink>
              );
            })}
          </div>
        </nav>
      </header>
      <main className="container py-8 md:py-12">{children}</main>
    </div>
  );
};
