import { Link } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { ArrowRight, Home, Calculator, LineChart, Sparkles } from "lucide-react";

export default function Index() {
  const { user } = useAuth();
  return (
    <div className="min-h-screen bg-gradient-cream">
      <header className="container flex items-center justify-between py-6">
        <div className="flex items-center gap-2">
          <div className="h-9 w-9 rounded-lg bg-gradient-warm grid place-items-center shadow-glow">
            <Home className="h-5 w-5 text-accent-foreground" />
          </div>
          <span className="font-display text-2xl font-semibold">Casa<span className="text-accent">.</span>plan</span>
        </div>
        {user ? (
          <Button asChild variant="secondary"><Link to="/app/objetivo">Abrir meu plano</Link></Button>
        ) : (
          <Button asChild variant="ghost"><Link to="/auth">Entrar</Link></Button>
        )}
      </header>

      <section className="container grid lg:grid-cols-2 gap-12 items-center py-16 md:py-24">
        <div className="space-y-6">
          <span className="inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-widest text-accent bg-accent/10 px-3 py-1.5 rounded-full">
            <Sparkles className="h-3 w-3" /> Planejamento para a entrada
          </span>
          <h1 className="font-display text-5xl md:text-7xl leading-[1.05]">
            A casa de vocês começa <em className="text-accent not-italic">aqui</em>.
          </h1>
          <p className="text-lg text-muted-foreground max-w-lg">
            Informe o valor do imóvel e descubra exatamente quanto você e seu par precisam guardar por mês — com simulação de CDI, IR regressivo e aportes extras.
          </p>
          <div className="flex flex-wrap gap-3 pt-2">
            <Button asChild size="lg" className="bg-gradient-warm text-accent-foreground hover:opacity-90 shadow-glow h-12 px-7">
              <Link to={user ? "/app/objetivo" : "/auth"}>
                Começar meu plano <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button asChild variant="ghost" size="lg" className="h-12">
              <a href="#como">Como funciona</a>
            </Button>
          </div>
          <div className="flex gap-6 pt-6 text-xs text-muted-foreground">
            <span>· Sem planilha</span><span>· Simulação real</span><span>· Para o casal</span>
          </div>
        </div>
        <div className="relative">
          <div className="absolute inset-0 bg-gradient-warm blur-3xl opacity-20 rounded-full" />
          <div className="relative rounded-3xl bg-gradient-ink text-primary-foreground p-8 shadow-elevated">
            <p className="text-xs uppercase tracking-widest opacity-60">Exemplo</p>
            <p className="font-display text-2xl mt-1">Apê de R$ 500.000</p>
            <div className="mt-6 space-y-3">
              <Row label="Entrada (20%)" value="R$ 100.000" />
              <Row label="Custos extras (5%)" value="R$ 25.000" />
              <Row label="Aporte mensal do casal" value="R$ 3.200" />
              <div className="h-px bg-white/10 my-4" />
              <Row label="Atinge meta em" value="34 meses" highlight />
              <Row label="Lucro com CDI" value="≈ R$ 14.700" highlight />
            </div>
          </div>
        </div>
      </section>

      <section id="como" className="container py-16 md:py-24 grid md:grid-cols-3 gap-6">
        {[
          { icon: Home, title: "Defina o imóvel", text: "Valor, % de entrada, prazo e custos extras (ITBI, escritura, registro)." },
          { icon: Calculator, title: "Cadastre o casal", text: "Renda e gastos de cada um. Sugerimos quanto cada pessoa pode aportar." },
          { icon: LineChart, title: "Simule e acompanhe", text: "Juros compostos, IR regressivo e aportes extras — tudo em um gráfico." },
        ].map((s, i) => (
          <div key={i} className="rounded-2xl bg-card border border-border/60 p-6 shadow-soft">
            <div className="h-10 w-10 rounded-lg bg-secondary grid place-items-center mb-4"><s.icon className="h-5 w-5" /></div>
            <h3 className="font-display text-xl mb-2">{s.title}</h3>
            <p className="text-sm text-muted-foreground">{s.text}</p>
          </div>
        ))}
      </section>

      <footer className="container py-10 text-xs text-muted-foreground border-t border-border/60">
        Cálculos didáticos. Não constituem recomendação de investimento.
      </footer>
    </div>
  );
}

function Row({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className="flex items-baseline justify-between">
      <span className="text-sm opacity-70">{label}</span>
      <span className={`font-display text-lg num ${highlight ? "text-accent" : ""}`}>{value}</span>
    </div>
  );
}
