import { useState } from "react";
import { AppShell } from "@/components/AppShell";
import { useObjetivo, Pessoa } from "@/hooks/useObjetivo";
import { useAuth } from "@/context/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { MoneyInput } from "@/components/MoneyInput";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { brl } from "@/lib/finance";
import { toast } from "sonner";
import { Plus, Trash2, ArrowRight, User } from "lucide-react";
import { useNavigate, Navigate } from "react-router-dom";

export default function PessoasPage() {
  const { user } = useAuth();
  const { objetivo, pessoas, loading, refresh } = useObjetivo();
  const navigate = useNavigate();
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ nome: "", renda_mensal: 0, gastos_mensais: 0 });

  if (loading) return <AppShell><div className="text-muted-foreground">Carregando…</div></AppShell>;
  if (!objetivo) return <Navigate to="/app/objetivo" replace />;

  const sobraTotal = pessoas.reduce((s, p) => s + (Number(p.renda_mensal) - Number(p.gastos_mensais)), 0);

  const adicionar = async () => {
    if (!user || !form.nome) return toast.error("Informe o nome");
    setAdding(true);
    const sobra = Math.max(0, form.renda_mensal - form.gastos_mensais);
    const { error } = await supabase.from("pessoas").insert({
      ...form,
      aporte_mensal: Math.round(sobra * 0.5), // sugestão: metade da sobra
      objetivo_id: objetivo.id,
      user_id: user.id,
    });
    setAdding(false);
    if (error) return toast.error(error.message);
    setForm({ nome: "", renda_mensal: 0, gastos_mensais: 0 });
    refresh();
  };

  const remover = async (id: string) => {
    const { error } = await supabase.from("pessoas").delete().eq("id", id);
    if (error) return toast.error(error.message);
    refresh();
  };

  const atualizarPessoa = async (p: Pessoa, patch: Partial<Pessoa>) => {
    const { error } = await supabase.from("pessoas").update(patch).eq("id", p.id);
    if (error) return toast.error(error.message);
    refresh();
  };

  return (
    <AppShell>
      <div className="max-w-5xl mx-auto space-y-8">
        <div>
          <p className="text-xs uppercase tracking-widest text-accent font-medium mb-2">Etapa 2 de 4</p>
          <h1 className="font-display text-4xl md:text-5xl mb-2">Quem está nessa?</h1>
          <p className="text-muted-foreground">Cadastre você e seu par. Calculamos a sobra mensal de cada um.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          {pessoas.map((p) => {
            const sobra = Number(p.renda_mensal) - Number(p.gastos_mensais);
            return (
              <Card key={p.id} className="p-6 shadow-soft space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-secondary grid place-items-center">
                      <User className="h-4 w-4" />
                    </div>
                    <Input
                      value={p.nome}
                      onChange={(e) => atualizarPessoa(p, { nome: e.target.value })}
                      className="font-display text-lg border-none px-0 focus-visible:ring-0 h-auto"
                    />
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => remover(p.id)}>
                    <Trash2 className="h-4 w-4 text-muted-foreground" />
                  </Button>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-xs">Renda mensal</Label>
                    <MoneyInput variant="money" value={Number(p.renda_mensal)}
                      onChange={(v) => atualizarPessoa(p, { renda_mensal: v })} />
                  </div>
                  <div>
                    <Label className="text-xs">Gastos mensais</Label>
                    <MoneyInput variant="money" value={Number(p.gastos_mensais)}
                      onChange={(v) => atualizarPessoa(p, { gastos_mensais: v })} />
                  </div>
                </div>
                <div className="rounded-lg bg-secondary/60 p-3 flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Sobra mensal</span>
                  <span className={`font-display text-xl num ${sobra >= 0 ? "text-success" : "text-destructive"}`}>{brl(sobra)}</span>
                </div>
              </Card>
            );
          })}

          <Card className="p-6 border-dashed shadow-none space-y-3">
            <h3 className="font-display text-lg">Adicionar pessoa</h3>
            <Input placeholder="Nome" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} />
            <div className="grid grid-cols-2 gap-3">
              <MoneyInput variant="money" value={form.renda_mensal}
                onChange={(v) => setForm({ ...form, renda_mensal: v })} placeholder="Renda" />
              <MoneyInput variant="money" value={form.gastos_mensais}
                onChange={(v) => setForm({ ...form, gastos_mensais: v })} placeholder="Gastos" />
            </div>
            <Button onClick={adicionar} disabled={adding} className="w-full" variant="secondary">
              <Plus className="h-4 w-4 mr-1" /> Adicionar
            </Button>
          </Card>
        </div>

        {pessoas.length > 0 && (
          <Card className="p-6 bg-gradient-ink text-primary-foreground shadow-elevated flex items-center justify-between">
            <div>
              <p className="text-xs uppercase tracking-widest opacity-70">Sobra total do casal</p>
              <p className="font-display text-3xl num mt-1">{brl(sobraTotal)}</p>
            </div>
            <Button onClick={() => navigate("/app/planejamento")} className="bg-gradient-warm text-accent-foreground hover:opacity-90">
              Ir para o plano <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Card>
        )}
      </div>
    </AppShell>
  );
}
