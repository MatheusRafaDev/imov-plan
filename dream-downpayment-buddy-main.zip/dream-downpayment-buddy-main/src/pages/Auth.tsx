import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { Home } from "lucide-react";

export default function Auth() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signup");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [nome, setNome] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) navigate("/app/objetivo", { replace: true });
  }, [user, navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signup") {
        const redirectUrl = `${window.location.origin}/app/objetivo`;
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: redirectUrl, data: { nome } },
        });
        if (error) throw error;
        toast.success("Conta criada! Você já pode entrar.");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (err: any) {
      toast.error(err.message ?? "Erro");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-gradient-cream">
      <div className="hidden lg:flex flex-col justify-between p-12 bg-gradient-ink text-primary-foreground relative overflow-hidden">
        <div className="flex items-center gap-2">
          <div className="h-9 w-9 rounded-lg bg-gradient-warm grid place-items-center"><Home className="h-5 w-5" /></div>
          <span className="font-display text-2xl">Casa<span className="text-accent">.</span>plan</span>
        </div>
        <div className="space-y-6 max-w-md">
          <h1 className="font-display text-5xl leading-tight">A entrada do seu imóvel, mês a mês.</h1>
          <p className="text-lg opacity-80">
            Calcule a meta, simule rendimento no CDI com IR regressivo e veja exatamente quando você chega lá.
          </p>
          <ul className="space-y-2 text-sm opacity-80">
            <li>· Plano para casal — cada um com seu aporte</li>
            <li>· Aportes extras (FGTS, bônus, freelance)</li>
            <li>· Simulação de juros compostos em tempo real</li>
          </ul>
        </div>
        <p className="text-xs opacity-60">Cálculos didáticos. Não constituem recomendação de investimento.</p>
      </div>
      <div className="flex items-center justify-center p-6 md:p-12">
        <Card className="w-full max-w-md p-8 shadow-elevated border-border/60">
          <div className="lg:hidden flex items-center gap-2 mb-6">
            <div className="h-8 w-8 rounded-lg bg-gradient-warm grid place-items-center"><Home className="h-4 w-4 text-accent-foreground" /></div>
            <span className="font-display text-xl">Casa<span className="text-accent">.</span>plan</span>
          </div>
          <h2 className="font-display text-3xl mb-1">{mode === "signup" ? "Crie sua conta" : "Entre na sua conta"}</h2>
          <p className="text-sm text-muted-foreground mb-6">
            {mode === "signup" ? "Comece seu plano em 2 minutos." : "Bem-vindo de volta."}
          </p>
          <form onSubmit={submit} className="space-y-4">
            {mode === "signup" && (
              <div>
                <Label htmlFor="nome">Seu nome</Label>
                <Input id="nome" value={nome} onChange={(e) => setNome(e.target.value)} required />
              </div>
            )}
            <div>
              <Label htmlFor="email">E-mail</Label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>
            <div>
              <Label htmlFor="password">Senha</Label>
              <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} />
            </div>
            <Button type="submit" className="w-full bg-gradient-warm text-accent-foreground hover:opacity-90 shadow-glow" disabled={loading}>
              {loading ? "Aguarde..." : mode === "signup" ? "Criar conta" : "Entrar"}
            </Button>
          </form>
          <button
            type="button"
            onClick={() => setMode(mode === "signup" ? "signin" : "signup")}
            className="mt-4 text-sm text-muted-foreground hover:text-foreground w-full text-center"
          >
            {mode === "signup" ? "Já tenho conta — entrar" : "Não tenho conta — criar"}
          </button>
        </Card>
      </div>
    </div>
  );
}
