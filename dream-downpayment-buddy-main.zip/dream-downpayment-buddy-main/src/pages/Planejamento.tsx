import { useMemo, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { useObjetivo, Pessoa } from "@/hooks/useObjetivo";
import { useAuth } from "@/context/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { MoneyInput } from "@/components/MoneyInput";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { brl, calcularMeta, mesesParaMeta, aporteNecessarioParaPrazo, mesesEntre } from "@/lib/finance";
import { toast } from "sonner";
import { ArrowRight, Plus, Trash2, Sparkles } from "lucide-react";
import { useNavigate, Navigate } from "react-router-dom";

const ORIGENS = ["FGTS", "Bônus / 13º", "Freelance", "Restituição IR", "Presente", "Outro"];

export default function PlanejamentoPage() {
  const { user } = useAuth();
  const { objetivo, pessoas, aportes, loading, refresh } = useObjetivo();
  const navigate = useNavigate();
  const [novoAporte, setNovoAporte] = useState({
    data: new Date().toISOString().slice(0, 10),
    valor: 0,
    origem: "Bônus / 13º",
    pessoa_id: "" as string,
  });

  const aporteTotal = pessoas.reduce((s, p) => s + Number(p.aporte_mensal ?? 0), 0);
  const meta = calcularMeta({
    valorImovel: Number(objetivo?.valor_imovel ?? 0),
    percentualEntrada: Number(objetivo?.percentual_entrada ?? 0),
    percentualCustosExtras: Number(objetivo?.percentual_custos_extras ?? 0),
  });

  const baseSim = useMemo(() => ({
    valorImovel: Number(objetivo?.valor_imovel ?? 0),
    percentualEntrada: Number(objetivo?.percentual_entrada ?? 0),
    percentualCustosExtras: Number(objetivo?.percentual_custos_extras ?? 0),
    valorJaGuardado: Number(objetivo?.valor_ja_guardado ?? 0),
    taxaCdiAnual: Number(objetivo?.taxa_cdi_anual ?? 0),
    percentualCdi: Number(objetivo?.percentual_cdi ?? 100),
    dataInicio: objetivo?.data_inicio ? new Date(objetivo.data_inicio) : new Date(),
    aportesExtras: aportes.map((a) => ({
      data: a.data, valor: Number(a.valor), origem: a.origem,
    })),
  }), [objetivo, aportes]);

  if (loading) return <AppShell><div className="text-muted-foreground">Carregando…</div></AppShell>;
  if (!objetivo) return <Navigate to="/app/objetivo" replace />;
  if (pessoas.length === 0) return <Navigate to="/app/pessoas" replace />;

  const prazoMeses = objetivo.data_inicio && objetivo.data_fim
    ? mesesEntre(objetivo.data_inicio, objetivo.data_fim)
    : objetivo.prazo_meses;
  const mesesEstimados = mesesParaMeta({ ...baseSim, aporteMensalTotal: aporteTotal });
  const aporteSugeridoPrazo = aporteNecessarioParaPrazo({ ...baseSim, prazoMeses });

  const atualizarPessoa = async (p: Pessoa, valor: number) => {
    const { error } = await supabase.from("pessoas").update({ aporte_mensal: valor }).eq("id", p.id);
    if (error) toast.error(error.message); else refresh();
  };

  const distribuirSugerido = async () => {
    // distribui proporcional à sobra
    const sobras = pessoas.map((p) => Math.max(1, Number(p.renda_mensal) - Number(p.gastos_mensais)));
    const total = sobras.reduce((a, b) => a + b, 0);
    await Promise.all(pessoas.map((p, i) => {
      const valor = Math.round((sobras[i] / total) * aporteSugeridoPrazo);
      return supabase.from("pessoas").update({ aporte_mensal: valor }).eq("id", p.id);
    }));
    toast.success("Aportes distribuídos");
    refresh();
  };

  const adicionarAporte = async () => {
    if (!user || !novoAporte.valor) return toast.error("Informe o valor");
    const { error } = await supabase.from("aportes_extras").insert({
      objetivo_id: objetivo.id,
      user_id: user.id,
      pessoa_id: novoAporte.pessoa_id || null,
      data: novoAporte.data,
      valor: novoAporte.valor,
      origem: novoAporte.origem,
    });
    if (error) return toast.error(error.message);
    setNovoAporte({ ...novoAporte, valor: 0 });
    refresh();
  };

  const removerAporte = async (id: string) => {
    const { error } = await supabase.from("aportes_extras").delete().eq("id", id);
    if (error) toast.error(error.message); else refresh();
  };

  return (
    <AppShell>
      <div className="max-w-6xl mx-auto space-y-8">
        <div>
          <p className="text-xs uppercase tracking-widest text-accent font-medium mb-2">Etapa 3 de 4</p>
          <h1 className="font-display text-4xl md:text-5xl mb-2">Monte o plano mensal</h1>
          <p className="text-muted-foreground">Defina quanto cada um aporta e adicione entradas extras.</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-4">
          <Card className="p-5 shadow-soft">
            <p className="text-xs uppercase tracking-widest text-muted-foreground">Aporte mensal total</p>
            <p className="font-display text-3xl num mt-1">{brl(aporteTotal)}</p>
          </Card>
          <Card className="p-5 shadow-soft">
            <p className="text-xs uppercase tracking-widest text-muted-foreground">Atinge a meta em</p>
            <p className="font-display text-3xl num mt-1">{mesesEstimados ? `${mesesEstimados} meses` : "—"}</p>
            <p className="text-xs text-muted-foreground mt-1">Meta: {brl(meta)}</p>
          </Card>
          <Card className="p-5 shadow-soft bg-secondary/40">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="text-xs uppercase tracking-widest text-muted-foreground">Sugestão p/ {prazoMeses}m</p>
                <p className="font-display text-3xl num mt-1">{brl(aporteSugeridoPrazo)}</p>
              </div>
              <Button size="sm" variant="ghost" onClick={distribuirSugerido} title="Distribuir entre as pessoas">
                <Sparkles className="h-4 w-4 mr-1" /> Aplicar
              </Button>
            </div>
          </Card>
        </div>

        <Card className="p-6 shadow-soft">
          <h2 className="font-display text-2xl mb-4">Aporte de cada pessoa</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            {pessoas.map((p) => (
              <div key={p.id} className="rounded-xl border border-border bg-card p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium">{p.nome}</span>
                  <span className="text-xs text-muted-foreground">sobra {brl(Number(p.renda_mensal) - Number(p.gastos_mensais))}</span>
                </div>
                <MoneyInput variant="money" value={Number(p.aporte_mensal)}
                  onChange={(v) => atualizarPessoa(p, v)}
                  className="font-display text-2xl num h-12" />
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-6 shadow-soft">
          <h2 className="font-display text-2xl mb-1">Aportes extras</h2>
          <p className="text-sm text-muted-foreground mb-4">FGTS, bônus, freelances, restituição — tudo que entra fora do mês.</p>

          <div className="grid md:grid-cols-5 gap-3 items-end mb-4">
            <div>
              <Label className="text-xs">Data</Label>
              <Input type="date" value={novoAporte.data} onChange={(e) => setNovoAporte({ ...novoAporte, data: e.target.value })} />
            </div>
            <div>
              <Label className="text-xs">Valor</Label>
              <MoneyInput variant="money" value={novoAporte.valor}
                onChange={(v) => setNovoAporte({ ...novoAporte, valor: v })} />
            </div>
            <div>
              <Label className="text-xs">Origem</Label>
              <Select value={novoAporte.origem} onValueChange={(v) => setNovoAporte({ ...novoAporte, origem: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {ORIGENS.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Pessoa</Label>
              <Select value={novoAporte.pessoa_id || "none"} onValueChange={(v) => setNovoAporte({ ...novoAporte, pessoa_id: v === "none" ? "" : v })}>
                <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Conjunto</SelectItem>
                  {pessoas.map((p) => <SelectItem key={p.id} value={p.id}>{p.nome}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <Button onClick={adicionarAporte} className="bg-gradient-warm text-accent-foreground hover:opacity-90">
              <Plus className="h-4 w-4 mr-1" /> Adicionar
            </Button>
          </div>

          {aportes.length === 0 ? (
            <p className="text-sm text-muted-foreground py-6 text-center border border-dashed rounded-lg">Nenhum aporte extra ainda.</p>
          ) : (
            <div className="divide-y divide-border border border-border rounded-lg overflow-hidden">
              {aportes.map((a) => {
                const pessoa = pessoas.find((p) => p.id === a.pessoa_id);
                return (
                  <div key={a.id} className="grid grid-cols-12 items-center gap-2 px-4 py-3 text-sm">
                    <span className="col-span-3 num">{new Date(a.data).toLocaleDateString("pt-BR")}</span>
                    <span className="col-span-3">{a.origem}</span>
                    <span className="col-span-3 text-muted-foreground">{pessoa?.nome ?? "Conjunto"}</span>
                    <span className="col-span-2 num font-medium">{brl(Number(a.valor))}</span>
                    <Button size="icon" variant="ghost" onClick={() => removerAporte(a.id)} className="col-span-1 justify-self-end">
                      <Trash2 className="h-4 w-4 text-muted-foreground" />
                    </Button>
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        <div className="flex justify-end">
          <Button onClick={() => navigate("/app/resultado")} className="bg-gradient-warm text-accent-foreground hover:opacity-90 shadow-glow">
            Ver resultado <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </AppShell>
  );
}
