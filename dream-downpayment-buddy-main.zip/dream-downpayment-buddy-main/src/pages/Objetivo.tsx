import { useEffect, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { useObjetivo } from "@/hooks/useObjetivo";
import { useAuth } from "@/context/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { MoneyInput } from "@/components/MoneyInput";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { brl, calcularEntrada, calcularCustosExtras, calcularMeta, mesesEntre } from "@/lib/finance";
import { toast } from "sonner";
import { Building2, Calendar, Percent, Wallet, ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";

const todayISO = () => new Date().toISOString().slice(0, 10);
const addMonthsISO = (iso: string, months: number) => {
  const d = new Date(iso);
  d.setMonth(d.getMonth() + months);
  return d.toISOString().slice(0, 10);
};

export default function ObjetivoPage() {
  const { user } = useAuth();
  const { objetivo, loading, refresh } = useObjetivo();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    nome: "Meu apê dos sonhos",
    valor_imovel: 500000,
    percentual_entrada: 20,
    data_inicio: todayISO(),
    data_fim: addMonthsISO(todayISO(), 36),
    valor_ja_guardado: 10000,
    taxa_cdi_anual: 13.65,
    percentual_cdi: 100,
    percentual_custos_extras: 5,
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (objetivo) {
      setForm({
        nome: objetivo.nome,
        valor_imovel: Number(objetivo.valor_imovel),
        percentual_entrada: Number(objetivo.percentual_entrada),
        data_inicio: objetivo.data_inicio ?? todayISO(),
        data_fim: objetivo.data_fim ?? addMonthsISO(objetivo.data_inicio ?? todayISO(), objetivo.prazo_meses ?? 36),
        valor_ja_guardado: Number(objetivo.valor_ja_guardado),
        taxa_cdi_anual: Number(objetivo.taxa_cdi_anual),
        percentual_cdi: Number(objetivo.percentual_cdi),
        percentual_custos_extras: Number(objetivo.percentual_custos_extras),
      });
    }
  }, [objetivo]);

  const prazoMeses = mesesEntre(form.data_inicio, form.data_fim);

  const meta = calcularMeta({ valorImovel: form.valor_imovel, percentualEntrada: form.percentual_entrada, percentualCustosExtras: form.percentual_custos_extras });
  const entrada = calcularEntrada(form.valor_imovel, form.percentual_entrada);
  const custos = calcularCustosExtras(form.valor_imovel, form.percentual_custos_extras);
  const falta = Math.max(0, meta - form.valor_ja_guardado);

  const salvar = async (avancar = false) => {
    if (!user) return;
    setSaving(true);
    try {
      const payload = { ...form, prazo_meses: prazoMeses };
      if (objetivo) {
        const { error } = await supabase.from("objetivos").update(payload).eq("id", objetivo.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("objetivos").insert({ ...payload, user_id: user.id });
        if (error) throw error;
      }
      toast.success("Objetivo salvo");
      await refresh();
      if (avancar) navigate("/app/pessoas");
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <AppShell><div className="text-muted-foreground">Carregando…</div></AppShell>;

  return (
    <AppShell>
      <div className="max-w-5xl mx-auto space-y-8">
        <div>
          <p className="text-xs uppercase tracking-widest text-accent font-medium mb-2">Etapa 1 de 4</p>
          <h1 className="font-display text-4xl md:text-5xl mb-2">Qual é o imóvel?</h1>
          <p className="text-muted-foreground">Defina o valor, a entrada e o prazo. Calculamos a meta automaticamente.</p>
        </div>

        <div className="grid lg:grid-cols-5 gap-6">
          <Card className="lg:col-span-3 p-6 md:p-8 space-y-5 shadow-soft">
            <div>
              <Label htmlFor="nome">Apelido do plano</Label>
              <Input id="nome" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} />
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <Label>Valor do imóvel</Label>
                <MoneyInput variant="money" value={form.valor_imovel}
                  onChange={(v) => setForm({ ...form, valor_imovel: v })} />
              </div>
              <div>
                <Label>% de entrada</Label>
                <MoneyInput variant="percent" value={form.percentual_entrada}
                  onChange={(v) => setForm({ ...form, percentual_entrada: v })} />
              </div>
              <div>
                <Label>Data de início</Label>
                <Input type="date" value={form.data_inicio}
                  onChange={(e) => setForm({ ...form, data_inicio: e.target.value })} />
              </div>
              <div>
                <Label>Data limite (quero comprar até…)</Label>
                <Input type="date" value={form.data_fim} min={form.data_inicio}
                  onChange={(e) => setForm({ ...form, data_fim: e.target.value })} />
              </div>
              <div>
                <Label>Já guardado</Label>
                <MoneyInput variant="money" value={form.valor_ja_guardado}
                  onChange={(v) => setForm({ ...form, valor_ja_guardado: v })} />
              </div>
              <div>
                <Label>CDI anual (%)</Label>
                <MoneyInput variant="percent" value={form.taxa_cdi_anual}
                  onChange={(v) => setForm({ ...form, taxa_cdi_anual: v })} />
              </div>
              <div>
                <Label>% do CDI do investimento</Label>
                <MoneyInput variant="percent" value={form.percentual_cdi}
                  onChange={(v) => setForm({ ...form, percentual_cdi: v })} />
              </div>
              <div className="sm:col-span-2">
                <Label>Custos extras (ITBI + escritura + registro) — % do imóvel</Label>
                <MoneyInput variant="percent" value={form.percentual_custos_extras}
                  onChange={(v) => setForm({ ...form, percentual_custos_extras: v })} />
              </div>
            </div>

            <div className="flex flex-wrap gap-3 pt-2">
              <Button onClick={() => salvar(false)} disabled={saving} variant="secondary">Salvar</Button>
              <Button onClick={() => salvar(true)} disabled={saving} className="bg-gradient-warm text-accent-foreground hover:opacity-90 shadow-glow">
                Salvar e seguir <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </Card>

          <div className="lg:col-span-2 space-y-4">
            <Card className="p-6 bg-gradient-ink text-primary-foreground shadow-elevated">
              <p className="text-xs uppercase tracking-widest opacity-70">Meta total</p>
              <p className="font-display text-4xl mt-1 num">{brl(meta)}</p>
              <p className="text-xs opacity-70 mt-2">Entrada + custos extras</p>
              <div className="mt-5 grid grid-cols-2 gap-4 pt-5 border-t border-white/10">
                <div>
                  <p className="text-xs opacity-70">Entrada ({form.percentual_entrada}%)</p>
                  <p className="font-display text-xl num">{brl(entrada)}</p>
                </div>
                <div>
                  <p className="text-xs opacity-70">Custos ({form.percentual_custos_extras}%)</p>
                  <p className="font-display text-xl num">{brl(custos)}</p>
                </div>
              </div>
            </Card>
            <Card className="p-6 shadow-soft">
              <p className="text-xs uppercase tracking-widest text-muted-foreground">Falta juntar</p>
              <p className="font-display text-3xl mt-1 num text-accent">{brl(falta)}</p>
              <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <Stat icon={<Building2 className="h-4 w-4" />} label="Imóvel" value={brl(form.valor_imovel)} />
                <Stat icon={<Calendar className="h-4 w-4" />} label="Prazo" value={`${prazoMeses} meses`} />
                <Stat icon={<Percent className="h-4 w-4" />} label="CDI ef." value={`${(form.taxa_cdi_anual * form.percentual_cdi / 100).toFixed(2)}% a.a.`} />
                <Stat icon={<Wallet className="h-4 w-4" />} label="Já tem" value={brl(form.valor_ja_guardado)} />
              </div>
            </Card>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-start gap-2">
      <div className="mt-0.5 text-muted-foreground">{icon}</div>
      <div>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="font-medium num">{value}</p>
      </div>
    </div>
  );
}
