import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";

export type Objetivo = {
  id: string;
  user_id: string;
  nome: string;
  valor_imovel: number;
  percentual_entrada: number;
  prazo_meses: number;
  data_inicio: string;
  data_fim: string;
  valor_ja_guardado: number;
  taxa_cdi_anual: number;
  percentual_cdi: number;
  percentual_custos_extras: number;
};

export type Pessoa = {
  id: string;
  objetivo_id: string;
  user_id: string;
  nome: string;
  renda_mensal: number;
  gastos_mensais: number;
  aporte_mensal: number;
};

export type AporteExtra = {
  id: string;
  objetivo_id: string;
  user_id: string;
  pessoa_id: string | null;
  data: string;
  valor: number;
  origem: string;
};

export function useObjetivo() {
  const { user } = useAuth();
  const [objetivo, setObjetivo] = useState<Objetivo | null>(null);
  const [pessoas, setPessoas] = useState<Pessoa[]>([]);
  const [aportes, setAportes] = useState<AporteExtra[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data: objs } = await supabase
      .from("objetivos")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: true })
      .limit(1);
    const obj = (objs?.[0] as Objetivo) ?? null;
    setObjetivo(obj);
    if (obj) {
      const [{ data: ps }, { data: aps }] = await Promise.all([
        supabase.from("pessoas").select("*").eq("objetivo_id", obj.id).order("created_at"),
        supabase.from("aportes_extras").select("*").eq("objetivo_id", obj.id).order("data"),
      ]);
      setPessoas((ps as Pessoa[]) ?? []);
      setAportes((aps as AporteExtra[]) ?? []);
    } else {
      setPessoas([]);
      setAportes([]);
    }
    setLoading(false);
  }, [user]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return { objetivo, pessoas, aportes, loading, refresh, setObjetivo, setPessoas, setAportes };
}
