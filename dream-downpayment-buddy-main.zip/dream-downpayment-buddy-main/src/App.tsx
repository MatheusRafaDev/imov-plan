import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/context/AuthContext";
import { RequireAuth } from "@/components/RequireAuth";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import Objetivo from "./pages/Objetivo";
import Pessoas from "./pages/Pessoas";
import Planejamento from "./pages/Planejamento";
import Resultado from "./pages/Resultado";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/app/objetivo" element={<RequireAuth><Objetivo /></RequireAuth>} />
            <Route path="/app/pessoas" element={<RequireAuth><Pessoas /></RequireAuth>} />
            <Route path="/app/planejamento" element={<RequireAuth><Planejamento /></RequireAuth>} />
            <Route path="/app/resultado" element={<RequireAuth><Resultado /></RequireAuth>} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
